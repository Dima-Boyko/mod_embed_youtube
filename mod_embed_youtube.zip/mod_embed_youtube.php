<?php
/*
*Имя приложения: Embed YouTune
*Версия:1
*Автор:Boyko Dmitry
*Дата:10.06.2018
*Описание:Вставляет видео с YouTune.
*/
defined('_JEXEC') or die('Restricted access');
// подключаем шаблон
require(JModuleHelper::getLayoutPath('mod_embed_youtube'));




